OMI — versión Glam V3

Esta versión incluye:
- Diseño más dinámico, femenino y glamuroso (negro + rosa + dorado).
- Botón flotante de WhatsApp visible en móvil y escritorio.
- Sección especial de Manicure & Pedicure con tres inspiraciones visuales.
- Video servido como archivo independiente: assets/omi-tienda.mp4
- Galería y datos actuales de OMI.

Las imágenes de uñas son INSPIRACIONES visuales, no trabajos reales de OMI. Se pueden reemplazar por fotos reales de manicure/pedicure.
